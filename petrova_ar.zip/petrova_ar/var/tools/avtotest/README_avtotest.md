1. Чтобы запустить автотест у вас должен быть установлен Codeception PHP Testing Framework v4.2.2
2. Поместите файл firstCest.php в папку tests\\acceptance
3. В файле acceptance.suite.yml укажите URL сайта
4. Запустите тест в консоли, используя команду php vendor/bin/codecept run --steps